def whoami():
    print("pkg_path_dist_b")
