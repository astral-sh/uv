def main():
    print("3")
