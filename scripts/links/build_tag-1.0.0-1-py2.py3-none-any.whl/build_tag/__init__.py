def main():
    print("1")
