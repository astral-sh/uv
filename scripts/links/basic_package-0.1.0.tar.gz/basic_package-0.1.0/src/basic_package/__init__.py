def hello() -> str:
    return "Hello from basic-package!"
