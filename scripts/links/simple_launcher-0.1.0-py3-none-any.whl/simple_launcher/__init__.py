def say_hi():
    print("Hi from the simple launcher!")