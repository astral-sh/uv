# SPDX-FileCopyrightText: 2024-present Charlie Marsh <charlie.r.marsh@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "999.0.0"
