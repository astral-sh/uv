# tqdm

[![PyPI - Version](https://img.shields.io/pypi/v/tqdm.svg)](https://pypi.org/project/tqdm)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tqdm.svg)](https://pypi.org/project/tqdm)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install tqdm
```

## License

`tqdm` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
