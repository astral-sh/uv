def main():
    print("5")
