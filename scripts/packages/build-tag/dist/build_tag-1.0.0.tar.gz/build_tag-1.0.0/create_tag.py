# scripts/build_tag.py
def get_version_data():
    return {"build_tag": "b1"}

if __name__ == "__main__":
    print("b1")
