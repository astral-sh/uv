def main() -> None:
    print("Hello from wheel-tag-test!")
