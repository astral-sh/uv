import pathlib
import zipfile


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    wheel_name = "source_package-1.0.0-py3-none-any.whl"
    wheel_path = pathlib.Path(wheel_directory, wheel_name)
    records = [
        ("source_package/__init__.py", b""),
        (
            "source_package-1.0.0.dist-info/METADATA",
            b"Metadata-Version: 2.1\nName: source-package\nVersion: 1.0.0\n",
        ),
        (
            "source_package-1.0.0.dist-info/WHEEL",
            b"Wheel-Version: 1.0\nGenerator: uv-test\nRoot-Is-Purelib: true\nTag: py3-none-any\n",
        ),
    ]
    with zipfile.ZipFile(wheel_path, "w") as wheel:
        for path, contents in records:
            wheel.writestr(path, contents)
        record = "\n".join(f"{path},," for path, _ in records)
        wheel.writestr(
            "source_package-1.0.0.dist-info/RECORD",
            record + "\nsource_package-1.0.0.dist-info/RECORD,,\n",
        )
    return wheel_name
