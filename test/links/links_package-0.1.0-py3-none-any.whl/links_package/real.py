# real module
VALUE = 42
