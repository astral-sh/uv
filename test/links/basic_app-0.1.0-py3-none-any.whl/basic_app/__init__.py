def main() -> None:
    print("Hello from basic-app!")
