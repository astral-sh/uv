from .circle import area as circle_area

__all__ = ["circle_area"]
