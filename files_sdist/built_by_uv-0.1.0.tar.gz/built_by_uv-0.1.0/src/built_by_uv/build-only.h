// There is no build step yet, but we're already modelling the basis for it by allowing files only in the source dist,
// but not in the wheel.

#include <pybind11/pybind11.h>
