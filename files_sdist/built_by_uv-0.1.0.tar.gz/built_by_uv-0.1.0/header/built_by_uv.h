#ifndef BUILT_BY_UV_H
#define BUILT_BY_UV_H

static inline const char* hello_world() {
    return "Hello World!";
}

#endif /* HELLO_WORLD_H */
