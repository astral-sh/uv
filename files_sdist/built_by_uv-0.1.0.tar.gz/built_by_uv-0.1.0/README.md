# built_by_uv

A package to be built with the uv build backend that uses all features exposed by the build backend.
