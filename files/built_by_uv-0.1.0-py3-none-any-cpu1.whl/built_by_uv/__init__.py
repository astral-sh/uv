def greet() -> str:
    return "Hello 👋"
