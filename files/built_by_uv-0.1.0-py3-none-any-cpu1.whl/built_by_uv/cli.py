def hello():
    print("Hi from a script!")
